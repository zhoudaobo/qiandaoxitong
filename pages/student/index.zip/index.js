
var wxCharts = require("../../../yilai/wxcharts.js");

var windowW = 0;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    pres: [
      { id: 1, preX: "java" },
      { id: 2, preX: "c++" },
      { id: 3, preX: "c#" },
      { id: 1, preX: "python" },
      { id: 2, preX: "英语" },
      { id: 3, preX: "高数" }
    ],
  },

  click: function (res) {
    console.log(res +"dfsfsd")
    wx.navigateTo({
      url: '../logs/logs',

    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    // 屏幕宽度
    this.setData({
      imageWidth: wx.getSystemInfoSync().windowWidth
    });
    // console.log(this.data.imageWidth);

    //计算屏幕宽度比列
    windowW = this.data.imageWidth / 375;
    // console.log(windowW);

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // columnCanvas
    new wxCharts({
      canvasId: 'columnCanvas',
      type: 'column',
      animation: true,
      categories: [2001, 2002, 2003, 2004, 2005],//横坐标
      series: [{
        name: '成交量',
        data: [15.00, 20.00, 45.00, 37.00],
        format: function (val, name) {
          return val.toFixed(2) + '万';
        }
      }, {
        name: '成交量',
        data: [6.00, 9.00, 20.00, 45.00],
        format: function (val, name) {
          return val.toFixed(2) + '万';
        },

      }],
      yAxis: {
        format: function (val) {
          return val + '万';
        },
        title: 'hello',
        min: 0
      },
      xAxis: {
        disableGrid: false,
        type: 'calibration'
      },
      extra: {
        column: {
          width: 15
        }
      },
      width: (375 * windowW),
      height: (200 * windowW),
    });
    

  },
})